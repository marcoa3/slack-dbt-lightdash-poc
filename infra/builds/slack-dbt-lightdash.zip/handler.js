"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const logger_1 = require("@beautypie/logger");
const logger = logger_1.defaultLogger;
// const DBT_ENDPOINT = "https://api.example.com/data";
// const SNOWFLAKE_ENDPOINT = "https://api.example.com/data";
// interface Metrics {
//   name: string;
//   dimensions: string;
//   description: string;
//   time_grains: string;
//   label: string;
// }
// interface DBTResponse {
//   compiled_code: string;
//   metrics: Metrics;
// }
const handler = async (event, context) => {
    const queryString = event.body;
    logger.info(`Recieved event with body '${queryString}' and with context: '${context}'`);
    return {
        statusCode: 200,
        body: "Hello world"
    };
    // try {
    //   const response = await fetch(apiUrl);
    //   const data: DBTResponse = await response.json();
    //   return {
    //     statusCode: 200,
    //     body: JSON.stringify(data)
    //   };
    // } catch (error) {
    //   logger.error(error);
    //   return {
    //     statusCode: 500,
    //     body: JSON.stringify({ message: "Error querying DBT", error: error })
    //   };
    // }
};
exports.handler = handler;
